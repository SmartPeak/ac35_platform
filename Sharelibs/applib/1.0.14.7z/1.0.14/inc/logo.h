#ifndef LOGOS_H
#define LOGOS_H

extern unsigned char pass_icon[];
extern unsigned char fail_icon[];

#endif
