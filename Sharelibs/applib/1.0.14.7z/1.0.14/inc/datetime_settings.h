/*
 * Copyright (C) 2018 Shanghai Basewin Technology Co.,Ltd
 */

#ifndef __DATETIME_SETTINGS_H
#define __DATETIME_SETTINGS_H

int datetime_settings_network_sync(void);
int datetime_settings_manual_set(void);
void datetime_sync_init(void);

#endif
